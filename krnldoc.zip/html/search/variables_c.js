var searchData=
[
  ['task_5fpool_230',['task_pool',['../krnl_8c.html#ae8508664812d71fc106d8929f6104cf6',1,'task_pool():&#160;krnl.c'],['../krnl_8h.html#ae8508664812d71fc106d8929f6104cf6',1,'task_pool():&#160;krnl.c']]],
  ['tcntvalue_231',['tcntValue',['../krnl_8c.html#a4b4a047399e1ee15b40777542d354b52',1,'krnl.c']]],
  ['timer0_5fmillis_232',['timer0_millis',['../krnl_8c.html#ab34d3974411fdee7da8c6b4f650502e9',1,'krnl.c']]],
  ['timer0_5foverflow_5fcount_233',['timer0_overflow_count',['../krnl_8c.html#a79a4c8c254cfb57c6ac3393a396c7a4f',1,'krnl.c']]],
  ['tmr_5findx_234',['tmr_indx',['../krnl_8c.html#aca8f692a56d85f636f0caaf14abd57d2',1,'krnl.c']]]
];
