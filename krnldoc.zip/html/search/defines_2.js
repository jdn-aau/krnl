var searchData=
[
  ['dmy_5fprio_240',['DMY_PRIO',['../krnl_8h.html#acf2f4a8f04e484305e7c862c0cb39d63',1,'krnl.h']]],
  ['dmy_5fstk_5fsz_241',['DMY_STK_SZ',['../krnl_8h.html#a1159800af031443d866b321adaae60d8',1,'krnl.h']]],
  ['dynmemory_242',['DYNMEMORY',['../krnl_8h.html#a874598d88f6cf5a05743c4544de5d3f0',1,'krnl.h']]]
];
