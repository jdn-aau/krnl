var searchData=
[
  ['fakecnt_18',['fakecnt',['../krnl_8c.html#ab6049c624c71022617cb364ecab34dba',1,'krnl.c']]],
  ['fakecnt_5fpreset_19',['fakecnt_preset',['../krnl_8c.html#ab86ac5ffb302fcda5e40378d29e70d40',1,'krnl.c']]],
  ['fract_5finc_20',['FRACT_INC',['../krnl_8c.html#a5647e40017bbd34a202f6a672ca116e4',1,'krnl.c']]],
  ['fract_5fmax_21',['FRACT_MAX',['../krnl_8c.html#a3d5262b0f828700a2ce29198838e0d9e',1,'krnl.c']]],
  ['freeram_22',['freeRam',['../krnl_8c.html#abde03a57484eac43bffbad24df5fc794',1,'freeRam(void):&#160;krnl.c'],['../krnl_8h.html#abde03a57484eac43bffbad24df5fc794',1,'freeRam(void):&#160;krnl.c']]]
];
