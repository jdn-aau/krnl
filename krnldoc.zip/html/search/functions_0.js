var searchData=
[
  ['_5f_5fattribute_5f_5f_139',['__attribute__',['../krnl_8c.html#ab04f0f0b9eae773e634b2af977e882a9',1,'__attribute__((naked, noinline)):&#160;krnl.c'],['../krnl_8c.html#a201468129b483039afc5a619e2d31097',1,'__attribute__((weak)):&#160;krnl.c'],['../krnl_8h.html#a8ef6b2b6aa7aae89a26b36a436d99712',1,'__attribute__((weak)) k_enable_wdt(void):&#160;krnl.h']]]
];
