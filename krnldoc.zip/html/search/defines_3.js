var searchData=
[
  ['fract_5finc_243',['FRACT_INC',['../krnl_8c.html#a5647e40017bbd34a202f6a672ca116e4',1,'krnl.c']]],
  ['fract_5fmax_244',['FRACT_MAX',['../krnl_8c.html#a3d5262b0f828700a2ce29198838e0d9e',1,'krnl.c']]]
];
