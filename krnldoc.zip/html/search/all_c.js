var searchData=
[
  ['main_5fprio_85',['MAIN_PRIO',['../krnl_8h.html#add243159986ad4ecae03a1e77c9dea6c',1,'krnl.h']]],
  ['mainpage_2ec_86',['mainpage.c',['../mainpage_8c.html',1,'']]],
  ['max_5fint_87',['MAX_INT',['../krnl_8h.html#aaa1ac5caef84256eaeb39594e58e096f',1,'krnl.h']]],
  ['max_5fsem_5fval_88',['MAX_SEM_VAL',['../krnl_8h.html#afe39f29482489a949f24b4f4de6e9163',1,'krnl.h']]],
  ['maxv_89',['maxv',['../structk__t.html#ab5c4013797f848b7f3d306c8b12375b0',1,'k_t']]],
  ['microseconds_5fper_5ftimer0_5foverflow_90',['MICROSECONDS_PER_TIMER0_OVERFLOW',['../krnl_8c.html#ab1d369d575d0937b2064adbaab91594d',1,'krnl.c']]],
  ['millis_5finc_91',['MILLIS_INC',['../krnl_8c.html#ab640966289e34d6fe31434f37090e6e6',1,'krnl.c']]]
];
