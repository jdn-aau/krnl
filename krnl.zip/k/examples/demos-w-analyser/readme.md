## Some examples with traces


Here is a number of examples
Each examples ha s a trace recorded with an analog discover II

See more  [here]}(http://jensd.dk/edu/doc/arduino/krnl/l2code.html)

J
