var searchData=
[
  ['fakecnt_368',['fakecnt',['../krnl_8c.html#ab6049c624c71022617cb364ecab34dba',1,'krnl.c']]],
  ['fakecnt_5fpreset_369',['fakecnt_preset',['../krnl_8c.html#ab86ac5ffb302fcda5e40378d29e70d40',1,'krnl.c']]],
  ['fifosem_370',['fifoSem',['../structk__rwlock__t.html#a8c862462bdc41938a22bfe8b0b600f37',1,'k_rwlock_t']]]
];
