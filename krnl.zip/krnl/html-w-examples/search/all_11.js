var searchData=
[
  ['readme_180',['README',['../md_README.html',1,'']]],
  ['r_181',['r',['../structk__msg__t.html#aac75863785b0f241b90e49b440f9cd4a',1,'k_msg_t']]],
  ['rdsem_182',['rdSem',['../structk__rwlock__t.html#a080277bf6ca592dde2e2418ce4456249',1,'k_rwlock_t']]],
  ['rdwrsem_183',['rdwrSem',['../structk__rwlock__t.html#ae4aaf9b7e9e668d89390f134d10b23e5',1,'k_rwlock_t']]],
  ['readerwriter_184',['READERWRITER',['../krnl_8h.html#aa5ef77acfcc0043bc185e0a2485beb21',1,'krnl.h']]],
  ['readme_2emd_185',['readme.md',['../readme_8md.html',1,'(Global Namespace)'],['../README_8md.html',1,'(Global Namespace)']]],
  ['reg_186',['reg',['../k05_8ino.html#a21ded974a9ad4fda9d23c2b3c652502c',1,'reg():&#160;k05.ino'],['../k06_8ino.html#a21ded974a9ad4fda9d23c2b3c652502c',1,'reg():&#160;k06.ino'],['../k07_8ino.html#a21ded974a9ad4fda9d23c2b3c652502c',1,'reg():&#160;k07.ino'],['../k08_8ino.html#a21ded974a9ad4fda9d23c2b3c652502c',1,'reg():&#160;k08.ino'],['../k09_8ino.html#a21ded974a9ad4fda9d23c2b3c652502c',1,'reg():&#160;k09.ino'],['../k10_8ino.html#a21ded974a9ad4fda9d23c2b3c652502c',1,'reg():&#160;k10.ino'],['../k11_8ino.html#a21ded974a9ad4fda9d23c2b3c652502c',1,'reg():&#160;k11.ino']]],
  ['reti_187',['RETI',['../k08isrsem_8ino.html#a12e8057446d5e6e89e804226cf7c4ec9',1,'k08isrsem.ino']]]
];
