var searchData=
[
  ['i_35',['i',['../k02twotasks_8ino.html#a59b5f70d95f641564c5199c696b87cfd',1,'k02twotasks.ino']]],
  ['if_36',['if',['../k08isrsem_8ino.html#aaf3c4d305e0a24a74e3ae102c3cd982d',1,'if(!k_running) goto exitt:&#160;k08isrsem.ino'],['../k08isrsem_8ino.html#a30c739e6e2c2daa41b41ba872814f276',1,'if(debounceTime &gt;(k_millis_counter - lastISR)):&#160;k08isrsem.ino'],['../k08isrsem_8ino.html#a77e19db7b43e3362f28d6b030e7ada40',1,'if(-1==ki_signal(syncSem)) ISRoverflow++:&#160;k08isrsem.ino']]],
  ['isr_37',['ISR',['../krnl_8c.html#a790cb408825575b88d1107608b1ff389',1,'krnl.c']]],
  ['isroverflow_38',['ISRoverflow',['../k08isrsem_8ino.html#a6c6991d0a7b91cadf689ec839f76ded7',1,'k08isrsem.ino']]]
];
