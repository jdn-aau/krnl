var searchData=
[
  ['readme_2emd_278',['readme.md',['../readme_8md.html',1,'(Global Namespace)'],['../README_8md.html',1,'(Global Namespace)']]]
];
