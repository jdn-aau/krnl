var searchData=
[
  ['delaymicroseconds_260',['delayMicroseconds',['../krnl_8c.html#a2a70fb8b5376dab50d4de2b14056ba87',1,'krnl.c']]],
  ['deq_261',['deQ',['../krnl_8c.html#a7ac8496c83319bfc569e4fdab8149940',1,'krnl.c']]]
];
