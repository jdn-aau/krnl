var searchData=
[
  ['k_5fbug_5fon_352',['k_bug_on',['../krnl_8h.html#a23817e99808ff4f90c585030d08ebcd4',1,'krnl.h']]],
  ['k_5fcoopflag_353',['k_coopFlag',['../krnl_8c.html#ae638d91473d3882dc6a4bb790b7619b4',1,'k_coopFlag():&#160;krnl.c'],['../krnl_8h.html#ae638d91473d3882dc6a4bb790b7619b4',1,'k_coopFlag():&#160;krnl.c']]],
  ['k_5ferr_5fcnt_354',['k_err_cnt',['../krnl_8c.html#ae320347a3a0f5d049aa456b4ebf21d28',1,'k_err_cnt():&#160;krnl.c'],['../krnl_8h.html#ae320347a3a0f5d049aa456b4ebf21d28',1,'k_err_cnt():&#160;krnl.c']]],
  ['k_5fmillis_5fcounter_355',['k_millis_counter',['../krnl_8c.html#af95ed4a3eb440bda3b8088a52e345f5b',1,'k_millis_counter():&#160;krnl.c'],['../krnl_8h.html#af95ed4a3eb440bda3b8088a52e345f5b',1,'k_millis_counter():&#160;krnl.c']]],
  ['k_5fmsg_356',['k_msg',['../krnl_8c.html#a11c6706cca7518dfd785ea9f37a8b9c8',1,'k_msg():&#160;krnl.c'],['../krnl_8h.html#a11c6706cca7518dfd785ea9f37a8b9c8',1,'k_msg():&#160;krnl.h']]],
  ['k_5fpreempt_5fflag_357',['k_preempt_flag',['../krnl_8h.html#ae4e85d39f2472afc0cf1a933ea6b3585',1,'krnl.h']]],
  ['k_5frunning_358',['k_running',['../krnl_8c.html#a5cd13e276eb8b12ec888845f354e159c',1,'k_running():&#160;krnl.c'],['../krnl_8h.html#a5cd13e276eb8b12ec888845f354e159c',1,'k_running():&#160;krnl.c']]],
  ['k_5fsem_359',['k_sem',['../krnl_8c.html#a3612c72062520ffab60364b0d956e431',1,'k_sem():&#160;krnl.c'],['../krnl_8h.html#a3612c72062520ffab60364b0d956e431',1,'k_sem():&#160;krnl.h']]],
  ['k_5ftask_360',['k_task',['../krnl_8c.html#a5f7cbf98727b1a04fadd5890d0278487',1,'k_task():&#160;krnl.c'],['../krnl_8h.html#a5f7cbf98727b1a04fadd5890d0278487',1,'k_task():&#160;krnl.c']]],
  ['k_5ftick_5fsize_361',['k_tick_size',['../krnl_8c.html#a156af655170a22467a9d657098c84e09',1,'krnl.c']]],
  ['k_5fwdt_5fenabled_362',['k_wdt_enabled',['../krnl_8h.html#a3a9fb8ad24046b7181bce9e77fcdc4f7',1,'krnl.h']]],
  ['krnl_5fpreempt_5fflag_363',['krnl_preempt_flag',['../krnl_8h.html#a2680e3dfc16aaf181f466757b1460793',1,'krnl.h']]]
];
