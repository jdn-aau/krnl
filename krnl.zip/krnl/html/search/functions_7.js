var searchData=
[
  ['jumper_267',['jumper',['../krnl_8c.html#a9e93bf68f5c7767915007c9641d97a37',1,'krnl.c']]]
];
