var searchData=
[
  ['prio_5fenq_201',['prio_enQ',['../krnl_8c.html#ae7d9dd598f0d68cea2903843117e8ebe',1,'krnl.c']]]
];
