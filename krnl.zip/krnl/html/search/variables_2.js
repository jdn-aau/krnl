var searchData=
[
  ['dmy_5fstk_375',['dmy_stk',['../krnl_8h.html#a38effc60e299ca322c0065e67270a933',1,'krnl.h']]]
];
