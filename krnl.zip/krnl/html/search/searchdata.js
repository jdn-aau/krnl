var indexSectionsWithContent =
{
  0: "_abcdefhijklmnpqrstvwz",
  1: "k",
  2: "kmr",
  3: "_defijkp",
  4: "acdefklmnprstvw",
  5: "bcdhklmqrswz",
  6: "kr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros",
  6: "Pages"
};

