var searchData=
[
  ['d8t13_428',['d8t13',['../krnl_8h.html#a797d23ae1a9ec1bbff081aaf33120dd2',1,'krnl.h']]],
  ['dmy_5fprio_429',['DMY_PRIO',['../krnl_8h.html#acf2f4a8f04e484305e7c862c0cb39d63',1,'krnl.h']]],
  ['dmy_5fstk_5fsz_430',['DMY_STK_SZ',['../krnl_8h.html#a1159800af031443d866b321adaae60d8',1,'krnl.h']]],
  ['dynmemory_431',['DYNMEMORY',['../krnl_8h.html#a874598d88f6cf5a05743c4544de5d3f0',1,'krnl.h']]]
];
