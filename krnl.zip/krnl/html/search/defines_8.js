var searchData=
[
  ['readerwriter_277',['READERWRITER',['../krnl_8h.html#aa5ef77acfcc0043bc185e0a2485beb21',1,'krnl.h']]]
];
