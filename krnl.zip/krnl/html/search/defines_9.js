var searchData=
[
  ['sbi_444',['sbi',['../krnl_8h.html#a0c2d2311a38720412c3a666d6562aac3',1,'krnl.h']]],
  ['sem_5fmax_5fvalue_445',['SEM_MAX_VALUE',['../krnl_8h.html#ad19aa3c51588a22a9ee6cff41740880a',1,'krnl.h']]],
  ['stak_5fhash_446',['STAK_HASH',['../krnl_8h.html#ae0f7f3fba8495af1a0d053fc1806bc09',1,'krnl.h']]]
];
