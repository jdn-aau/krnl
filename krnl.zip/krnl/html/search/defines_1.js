var searchData=
[
  ['cbi_436',['cbi',['../krnl_8h.html#a555e11de39c12f2211225aacafe06e06',1,'cbi():&#160;krnl.h'],['../krnl_8h.html#a555e11de39c12f2211225aacafe06e06',1,'cbi():&#160;krnl.h']]],
  ['ceilingfailnotceil_437',['CEILINGFAILNOTCEIL',['../krnl_8h.html#ab1808c80437276ecdaa6c100347eeaf4',1,'krnl.h']]],
  ['ceilingfailprio_438',['CEILINGFAILPRIO',['../krnl_8h.html#a11bc43e769d3bfc5dd9eed4b0e843ea8',1,'krnl.h']]]
];
