var searchData=
[
  ['getdataincritregion_261',['getDataInCritRegion',['../k07mutexceiling_8ino.html#adb5c186df12ec23a7f20bc16d3b01b12',1,'getDataInCritRegion(void):&#160;k07mutexceiling.ino'],['../k07mutexsem_8ino.html#adb5c186df12ec23a7f20bc16d3b01b12',1,'getDataInCritRegion(void):&#160;k07mutexsem.ino'],['../k07mutexsem-adv_8ino.html#adb5c186df12ec23a7f20bc16d3b01b12',1,'getDataInCritRegion(void):&#160;k07mutexsem-adv.ino']]]
];
