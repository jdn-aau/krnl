var searchData=
[
  ['ei_441',['EI',['../krnl_8h.html#a54322f0fb4209b096e8e3b5864b46875',1,'krnl.h']]]
];
