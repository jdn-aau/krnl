var searchData=
[
  ['readme_120',['README',['../md_README.html',1,'']]],
  ['r_121',['r',['../structk__msg__t.html#aac75863785b0f241b90e49b440f9cd4a',1,'k_msg_t']]],
  ['rdsem_122',['rdSem',['../structk__rwlock__t.html#a080277bf6ca592dde2e2418ce4456249',1,'k_rwlock_t']]],
  ['rdwrsem_123',['rdwrSem',['../structk__rwlock__t.html#ae4aaf9b7e9e668d89390f134d10b23e5',1,'k_rwlock_t']]],
  ['readerwriter_124',['READERWRITER',['../krnl_8h.html#aa5ef77acfcc0043bc185e0a2485beb21',1,'krnl.h']]],
  ['readme_2emd_125',['README.md',['../README_8md.html',1,'']]]
];
