var searchData=
[
  ['max_5fint_451',['MAX_INT',['../krnl_8h.html#aaa1ac5caef84256eaeb39594e58e096f',1,'krnl.h']]],
  ['max_5fsem_5fval_452',['MAX_SEM_VAL',['../krnl_8h.html#afe39f29482489a949f24b4f4de6e9163',1,'krnl.h']]]
];
