var searchData=
[
  ['r_172',['r',['../structk__msg__t.html#aac75863785b0f241b90e49b440f9cd4a',1,'k_msg_t']]],
  ['readme_173',['README',['../md_README.html',1,'']]],
  ['readme_2emd_174',['README.md',['../README_8md.html',1,'']]],
  ['resetfunc_175',['resetFunc',['../k00hacksPWM_8ino.html#af470ac2a95380c26878282f7ddf529de',1,'resetFunc():&#160;k00hacksPWM.ino'],['../k01myfirsttask_8ino.html#af470ac2a95380c26878282f7ddf529de',1,'resetFunc():&#160;k01myfirsttask.ino']]],
  ['reti_176',['RETI',['../krnl_8h.html#a8513872c337c84cc24af517c5ef3605a',1,'RETI():&#160;krnl.h'],['../k08isrsem_8ino.html#a12e8057446d5e6e89e804226cf7c4ec9',1,'RETI():&#160;k08isrsem.ino']]]
];
