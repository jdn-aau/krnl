var searchData=
[
  ['saved_5fprio_126',['saved_prio',['../structk__t.html#af62d9822f6ab9a5a01f15dc43bc8b1aa',1,'k_t']]],
  ['sbi_127',['sbi',['../krnl_8h.html#a0c2d2311a38720412c3a666d6562aac3',1,'krnl.h']]],
  ['sem_128',['sem',['../structk__msg__t.html#abc38d50a3f77336df86ddc6a55665c0e',1,'k_msg_t']]],
  ['sem_5fmax_5fvalue_129',['SEM_MAX_VALUE',['../krnl_8h.html#ad19aa3c51588a22a9ee6cff41740880a',1,'krnl.h']]],
  ['sem_5fpool_130',['sem_pool',['../krnl_8c.html#a7734e7465577a12ef1bee5923cc7b121',1,'sem_pool():&#160;krnl.c'],['../krnl_8h.html#a7734e7465577a12ef1bee5923cc7b121',1,'sem_pool():&#160;krnl.h']]],
  ['send_5fpool_131',['send_pool',['../krnl_8c.html#ad1488042c624f027559bf393cb60030c',1,'send_pool():&#160;krnl.c'],['../krnl_8h.html#ad1488042c624f027559bf393cb60030c',1,'send_pool():&#160;krnl.c']]],
  ['sp_5fhi_132',['sp_hi',['../structk__t.html#acb129ee9a4e02ae9c68d07c72c0db02d',1,'k_t']]],
  ['sp_5flo_133',['sp_lo',['../structk__t.html#a1e6a2845b26a85e548e64a8ae310d7ac',1,'k_t']]],
  ['stak_5fhash_134',['STAK_HASH',['../krnl_8h.html#ae0f7f3fba8495af1a0d053fc1806bc09',1,'krnl.h']]]
];
