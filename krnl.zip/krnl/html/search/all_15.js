var searchData=
[
  ['zombi_5fprio_142',['ZOMBI_PRIO',['../krnl_8h.html#ac72d3be88c0ebe1484d661ed66b3edff',1,'krnl.h']]]
];
