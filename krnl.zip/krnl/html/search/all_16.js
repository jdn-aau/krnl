var searchData=
[
  ['x_229',['x',['../k04periodic-clip_8ino.html#a6150e0515f7202e2fb518f7206ed97dc',1,'k04periodic-clip.ino']]]
];
