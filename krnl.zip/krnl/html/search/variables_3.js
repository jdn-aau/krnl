var searchData=
[
  ['el_5fsize_210',['el_size',['../structk__msg__t.html#a9e6cf0aaaa54e2c69938457b2a16e512',1,'k_msg_t']]]
];
