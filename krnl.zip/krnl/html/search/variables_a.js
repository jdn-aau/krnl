var searchData=
[
  ['r_411',['r',['../structk__msg__t.html#aac75863785b0f241b90e49b440f9cd4a',1,'k_msg_t']]],
  ['rdsem_412',['rdSem',['../structk__rwlock__t.html#a080277bf6ca592dde2e2418ce4456249',1,'k_rwlock_t']]],
  ['rdwrsem_413',['rdwrSem',['../structk__rwlock__t.html#ae4aaf9b7e9e668d89390f134d10b23e5',1,'k_rwlock_t']]]
];
