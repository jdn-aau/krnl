var searchData=
[
  ['jquery_2ejs_81',['jquery.js',['../jquery_8js.html',1,'']]],
  ['jumper_82',['jumper',['../krnl_8c.html#a9e93bf68f5c7767915007c9641d97a37',1,'krnl.c']]]
];
